from . import linalg, spectral, myplot, utils

__version__ = '0.2.5'
