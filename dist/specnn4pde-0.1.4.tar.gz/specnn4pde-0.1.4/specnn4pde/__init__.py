from . import linalg, spectral, utils

__version__ = '0.1.4'
