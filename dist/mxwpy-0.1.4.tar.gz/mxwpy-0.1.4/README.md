# mxwpy
efficient numerical schemes
