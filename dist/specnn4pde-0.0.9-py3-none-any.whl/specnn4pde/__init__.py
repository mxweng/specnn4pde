from . import linalg, spectral, utils

__version__ = '0.0.9'
