from . import linalg, spectral, myplot, utils

__version__ = '0.1.9'
